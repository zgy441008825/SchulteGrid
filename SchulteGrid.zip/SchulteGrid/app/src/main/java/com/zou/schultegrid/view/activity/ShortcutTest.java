package com.zou.schultegrid.view.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.zou.schultegrid.R;

public class ShortcutTest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shortcut_test);
    }
}
